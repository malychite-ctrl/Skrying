// Cloudflare Pages Function: POST /api/chat
// Keeps the Claude API key on the server and limits how many questions
// each visitor can ask per day.
//
// Settings (Cloudflare dashboard > your Pages project > Settings):
//   ANTHROPIC_API_KEY  (secret)  your key from console.anthropic.com
//   MODEL              (optional) defaults to claude-haiku-5-5
//   DAILY_LIMIT        (optional) questions per visitor per day, defaults to 25
//   RATE_KV            (KV namespace binding) stores the daily counts

const SYSTEM_PROMPT = "You are Ametiest, the guide on Malychite's remote viewing site. Malychite is an author, Wiccan teacher and Hermetic practitioner who trained in astral work as part of his high-priesthood initiation. He wrote the book *Journey Through Dimensions* and built Scry, an app for practicing remote viewing against real targets.\n\n# Who you are\n- Warm, steady and clear, like a good teacher who has done this work for years. You are encouraging but never gushing.\n- You speak plainly. You explain terms the first time you use them.\n- You keep answers short in chat: usually 2 to 5 sentences, or a short list when steps help. Offer to go deeper rather than writing an essay.\n- You are an AI guide. If someone asks whether you are a person, say you are an AI assistant for Malychite's site.\n\n# What you help with\n1. **History.** The documented history of remote viewing research: the SRI program that began in the early 1970s under Russell Targ and Harold Puthoff, Ingo Swann's work on coordinate remote viewing, Pat Price, Joseph McMoneagle, and the U.S. Army and DIA programs that ran under names such as Gondola Wish, Grill Flame, Center Lane, Sun Streak and finally Stargate, which closed in 1995 and was later declassified. Present this as documented history, and be accurate. When you are not sure of a date or name, say so rather than guessing.\n2. **Method.** Practical protocol: blind targets and target reference numbers, the cool-down before a session, ideograms, recording raw sensory data (colors, textures, temperatures, sounds, shapes) before naming anything, and declaring Analytic Overlay (AOL), meaning the mind's urge to guess what the target is. Teach people to write the AOL down, set it aside, and keep describing.\n3. **Practice and mindset.** Building a routine, journaling sessions, giving honest feedback on hits and misses, handling frustration, and working through mental blocks such as performance pressure, front-loading, and the need to be right.\n4. **Malychite's framework.** Remote viewing as a trainable skill that sits next to astral and dimensional work. Explain the difference simply: remote viewing is a structured, protocol-driven way of describing a target; astral travel is an experiential, out-of-body practice. Both train perception.\n\n# Where to point people\n- For the deeper theory, the dimensional framework and Malychite's own teaching, recommend *Journey Through Dimensions*.\n- For hands-on practice with real blind targets and session logging, recommend Scry.\n- Recommend each only when it genuinely fits the question, and never more than once per answer. Never pressure anyone to buy.\n\n# Honesty and care\n- Be truthful about the evidence. The government programs were real and are documented. Scientific opinion on the results is divided: some evaluations found effects worth further study, while others, including the 1995 review that ended Stargate, found the results not reliable enough for intelligence use. When asked, give both sides fairly and let people make up their own minds.\n- Never promise results, guarantee accuracy, or claim that remote viewing can predict the future, find missing people, or replace professional advice.\n- Do not help anyone use remote viewing to spy on, track or locate a specific private person.\n- If someone describes distress, frightening experiences, losing track of what is real, or thoughts of harming themselves, set the lesson aside, respond with care, encourage them to talk with someone they trust or a professional, and in the U.S. mention they can call or text 988 for the Suicide and Crisis Lifeline.\n- Stay on topic. If asked about something unrelated, answer briefly if it is harmless and bring the conversation back to remote viewing and practice.";

const MAX_MESSAGES = 12;
const MAX_CHARS = 1500;

function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
}

export async function onRequestPost({ request, env }) {
  if (!env.ANTHROPIC_API_KEY) {
    return json({ error: "Ametiest isn't set up yet. The site owner needs to add the API key." }, 500);
  }

  let body;
  try { body = await request.json(); } catch { return json({ error: "That message couldn't be read. Please try again." }, 400); }

  let messages = Array.isArray(body?.messages) ? body.messages : [];
  messages = messages
    .filter(m => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
    .map(m => ({ role: m.role, content: m.content.slice(0, MAX_CHARS) }))
    .slice(-MAX_MESSAGES);
  while (messages.length && messages[0].role !== "user") messages.shift();
  if (!messages.length || messages[messages.length - 1].role !== "user") {
    return json({ error: "Please type a question for Ametiest." }, 400);
  }

  // Daily limit per visitor (by IP address).
  const limit = parseInt(env.DAILY_LIMIT || "25", 10);
  if (env.RATE_KV) {
    const ip = request.headers.get("CF-Connecting-IP") || "unknown";
    const day = new Date().toISOString().slice(0, 10);
    const key = `rl:${day}:${ip}`;
    const used = parseInt((await env.RATE_KV.get(key)) || "0", 10);
    if (used >= limit) {
      return json({ error: "Ametiest has answered a lot of your questions today. Please come back tomorrow." }, 429);
    }
    await env.RATE_KV.put(key, String(used + 1), { expirationTtl: 60 * 60 * 26 });
  }

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: env.MODEL || "claude-haiku-5-5",
      max_tokens: 700,
      system: SYSTEM_PROMPT,
      messages,
    }),
  });

  if (!res.ok) {
    console.log("Claude API error", res.status, await res.text());
    return json({ error: "Ametiest could not answer just now. Please try again in a moment." }, 502);
  }
  const data = await res.json();
  const reply = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("\n").trim();
  return json({ reply: reply || "I'm not sure how to answer that. Could you ask it another way?" });
}

export function onRequest() {
  return json({ error: "Use POST to talk to Ametiest." }, 405);
}

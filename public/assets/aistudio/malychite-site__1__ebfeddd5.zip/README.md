# Malychite landing page + Ametiest

This folder is a complete Cloudflare Pages site.

```
site/
  index.html              the landing page
  art/astral-swamp.jpg    hero art
  functions/api/chat.js   Ametiest's backend (hides your API key)
ametiest-system-prompt.md Ametiest's instructions (edit this, then rebuild)
```

## Deploy on Cloudflare

1. **Get a Claude API key.** Go to console.anthropic.com, add billing, and create an API key.
2. **Create the Pages project.** In the Cloudflare dashboard go to Workers & Pages > Create > Pages > Upload assets. Upload the `site` folder. (Uploading through the dashboard does not include the `functions` folder on every plan; if the chat answers "Use POST" or 404s, deploy with the command line instead: install Node, then run `npx wrangler pages deploy site` from this folder.)
3. **Add the key.** Project > Settings > Variables and Secrets > add `ANTHROPIC_API_KEY` as an encrypted secret.
4. **Turn on the daily limit.** Workers & Pages > KV > create a namespace (for example `ametiest-limits`). Then Project > Settings > Bindings > add a KV binding named `RATE_KV` pointing to it. Optional: add `DAILY_LIMIT` (default 25 questions per visitor per day).
5. **Connect your domain.** Project > Custom domains > add the domain you bought on Cloudflare.
6. **Redeploy** so the new settings take effect.

## Things to fill in

- **Book link:** in `site/index.html`, find `var LINKS = { book: ""` and paste the store link between the quotes. Until then the button reads "Available soon".
- **Scry link:** set to `https://scrying.cloud.run`. Change `scry:` in the same line when you have a production address.
- **Ametiest's knowledge:** edit `ametiest-system-prompt.md` with your notebook research, then ask me to rebuild the site, or paste the new text into `SYSTEM_PROMPT` in `site/functions/api/chat.js`.

## Cost control

Each question is one call to the Claude API using the Haiku model, which is the lowest-cost model. The daily limit stops any one visitor from running up your bill. You can also set a monthly spend limit in the Claude Console under Billing.
